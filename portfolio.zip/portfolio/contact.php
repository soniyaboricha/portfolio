<?php 

  $name = $_POST['name'];
 $subject = $_POST['subject'];
  $email = $_POST['email'];
  $message = $_POST['message'];
   if ($name && $subject && $email && $message) 
   {
      $to ="shboricha13it@gmail.com";  
   $subject ="Portfolio inquiry";
   $from = $email;
   $createDate = date('d-m-Y h:i:s');
   
   $headers  = 'MIME-Version: 1.0' . "\r\n";
   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
   $headers .= 'From: '.$from."\r\n".'Reply-To: '.$from."\r\n" .'X-Mailer: PHP/' . phpversion();
   
    $user_msg = '<html>
<head>
<title>Form</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="https://fonts.googleapis.com/css?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body style="font-family:"Quicksand"6, sans-serif!important; background: #ccc;">

<section style="border-bottom: 10px solid #d42225;  border-top: 10px solid #d42225; padding: 30px; width: 600px;height: 800px;background:#fff;margin: 0px auto;">
<div class="left" style="width: 300px;
height: 75px;">

</div>
<div class="right" style="width: 600px;height: 50px;float: left;">
<h3 style="font-weight: bold;">hello soniya boricha ,</h3>
<h3 style="font-weight: bold;">you have got one new contact from recruiter ,</h3>
<h3 style="font-weight: bold;">contacter name:'.$name.',</h3>
<h3 style="font-weight: bold;">contacter subject:'.$subject.',</h3>
<h3 style="font-weight: bold;">contacter email:'.$email.',</h3>
<h3 style="font-weight: bold;">contacter message:'.$message.'</h3>
</div>

</section>

   </body>
   </html>'; 


   mail($to,$subject,$user_msg,$headers);
         ?>        
<script type="text/javascript">
alert("Your contact with soniya boricha has been done thanks for contacting with her she will get to you back as soon as possible..."); 
window.location="index.php";
</script>  
   <?php
}



else
{
?>
<script type="text/javascript">
alert("error in enquiry"); 
window.location="index.php";
</script>   
<?php

}

?>